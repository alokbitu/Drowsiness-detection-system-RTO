// Copyright (C) 2005  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_CRc32_
#define DLIB_CRc32_


#include "crc32/crc32_kernel_1.h"

#endif // DLIB_CRc32_

